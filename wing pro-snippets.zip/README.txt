1. snippets文件夹的位置：c:\Users\${username}\AppData\Roaming\Wing Pro 7。
2. 我们只关注其中的py文件夹，主要用于存储python的snipptes。
3. 修改部分如下所示：
- file，主要是用于python文件的定义；
- class.ctx目录中的def，主要是用于类中方法的定义；
- module.ctx 目录中的def，主要是用于模块中方法的定义；
- module.ctx 目录中的class，主要是用于模块中类的定义；

